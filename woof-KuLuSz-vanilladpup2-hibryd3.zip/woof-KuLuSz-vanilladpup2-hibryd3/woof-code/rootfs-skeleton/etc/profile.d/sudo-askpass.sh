#!/bin/bash
alias sudo='[ -t 0 ]&& sudo|| sudo -A'