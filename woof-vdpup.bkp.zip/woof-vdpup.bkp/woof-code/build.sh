#!/bin/bash
#HackMod by nocsak at y2024 m08 d11
#Made by KuLuSz at y2024 m04 d00

if ! pidof sudo >/dev/null ;then
echo -e "\n###   Need root privileges!\n"
sudo "$0"
exit
fi

#directories
DIR="$(dirname "$(readlink -f "$0")")"
cd "$DIR"

M=
. ./DISTRO_SPECS 2>/dev/null || M=" SPECS"
. ./DISTRO_BUILD 2>/dev/null || M=" BUILD$M"
[ -n "$M" ]&& echo -e "\n ERROR: general error
 Build configuration files ($M ) does not exsist.
 Start the merge2out script in the parent directory.\n" && exit
 
. ./DISTRO_PKGS_SPECS

CHROOT="${DIR}/chroot"
ISO_ROOT="${DIR}/ISO"
ISO_LIVE="${ISO_ROOT}/$DISTRO_FILE_PREFIX"
mkdir -p "${CHROOT}" "${ISO_LIVE}"

#make sure, device can build the system
DEVICE="$(df . --output=source,target | tail -1)"
MNT_DEV="$(echo "$DEVICE" | awk '{print $1}')"
MNT_POINT="$(echo "$DEVICE" | awk '{print $2}')"
OPTS="$(grep -e "$MNT_POINT" /proc/mounts | awk '{print $4}')"
if [[ "$(echo "$OPTS" | grep 'nodev\|noexec')" ]];then
 OPTS="$(echo "$OPTS" | sed 's/nodev/dev/g ; s/noexec/exec/g')"
 mount -o remount,"$OPTS" $MNT_DEV $MNT_POINT
fi

#made log file from build
LOG="$ISO_ROOT/devuan_builder_$(date +y%Y-m%m-d%d_h%H-m%M-s%S).txt"
exec 1> >(tee -a "$LOG" /dev/console) 2>&1

echo -e "\nDistro specs:\n\n $(cat ./DISTRO_SPECS)\n\nAdditional variables of build:\n\n$(cat ./DISTRO_BUILD)\n" >> "$LOG"

mkdir -p "$CHROOT"

#			2 ASCII			Debian 9  Stretch
#			3 Beowulf		Debian 10 Buster
#			4 Chimaera		Debian 11 Bullseye
#			5 Daedalus		Debian 12 Bookworm
#			6 Excalibur		Debian 13 Trixie
#			7 Freia				Debian 14 Forky
#			8 Gryphon		Debian 15 Duke

#user agent for wget
uagent="Mozilla/5.0 (Linux; Android 8.1.0; Smart Box G2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Safari/537.36 OPR/63.3.3216.58675"

#manipulate repo packages for debootstrap
kernel=linux-image-${KARCH}
browser=chromium
netmgr=connman-gtk
clipboard=parcellite
vte9=libvte9
xml2=libxml2
fshot=flameshot
if [ "$DEB_VER" == "9" ];then
	fshot=scrot
	netmgr='wpagui network-manager'
elif [ "$DEB_VER" -ge "13" ];then
	[ "$ARCH" == "i386" ]&& kernel=
	[ "$DEB_VER" == "13" ]&& clipboard=
	vte9=libvte9t64
	[ "$DEB_VER" -ge "14" ]&& xml2=
fi

INCLUDES="$(echo "$kernel $browser $netmgr $clipboard $vte9 $xml2 $fshot $PKGS"  | sed 's/[ |\t]*#.*// ; /^$/d' |  sed 's/$/,/ ; $s/,$// ; s/ /,/g' | tr -d '\n')"

  DEB="debootstrap_1.0.141devuan1_all.deb" 
  wget -q -nc --no-check-certificate --user-agent="${uagent}" "$MIRROR/devuan/pool/main/d/debootstrap/$DEB"
  if [[ -f $DIR/$DEB ]];then
  echo -e "Base system built with: $DEB\n" >> "$LOG"
  else 
  exit
  fi

  echo -n " Install $DEB devuan package..."
  [ "$(which gdebi)" ]&& gdebi ./debootstrap*.deb || dpkg-deb -x ./debootstrap*.deb /
  [ "$?" -eq 0 ]&& echo "    DONE" || echo "    FAILED"
  echo -e "---------------------\n Start debootstrap...\n---------------------"
   debootstrap --arch="${ARCH}" --components=main,contrib,free,non-free,non-free-firmware \
   --include="$INCLUDES" --variant=minbase "${DISTRO_COMPAT_VERSION}" "$CHROOT" "$MIRROR"/merged
  echo -e "-----------------\n Debootstrap END.\n-----------------"

echo -n "Error in pkg list:  "
grep "Couldn't find these debs" "$LOG" && exit 1 || echo no

cp -rf ./rootfs-skeleton/* "$CHROOT"

echo "Unpacking some b43 firmware... please wait... "
mv "$CHROOT"/var/lib/dpkg/info/firmware-b43-installer.postinst "$CHROOT"/var/lib/dpkg/info/firmware-b43-installer.sh
	#Add b43 firmwares
	SITE="https://sources.openwrt.org"
	B43_PKG="$(wget -q -O- ${SITE} | awk -F'<|>' '/\-wl\-.*[0-9]\.tar/{print $3}' | tail -1)"
	if [ "${B43_PKG}" != "" ];then
	cd "$CHROOT"
	wget -q "${SITE}/${B43_PKG}"
	tar -xjf "${B43_PKG}"
	FILE="$(find "$CHROOT"/bro* -name *apsta* | sed 's:.*chroot::')"
	chroot "$CHROOT" b43-fwcutter -w /lib/firmware $FILE
	rm -rf "$CHROOT"/bro*
	cd "$DIR"
	fi

echo " Preparing chroot..."

	# made xterm
	chroot "$CHROOT" ln -s /usr/bin/lxterminal /usr/bin/xterm

	#remove root password
	chroot "$CHROOT" passwd -d root
	#chroot "$CHROOT" echo "root:root" | chpasswd

	#create live user
	chroot "$CHROOT" useradd live -s /bin/bash -U
	chroot "$CHROOT" passwd -d live
	#chroot "$CHROOT" echo "live:live" | chpasswd
	chroot "$CHROOT" usermod -a -G live live

	#check packages integrity
	chroot "${CHROOT}" apt-get update
	chroot "${CHROOT}" apt-get -f install -y &
	wait $!
   echo -e "\n\n Unofficial packages (hidden install) URLs:\n"
   mkdir -p "$ISO_ROOT"/hidden-packages
   echo "# These packages are no available in the current repository."
   
   if [ -z "$kernel" ]&& [ "$ARCH" == "i386" ];then
   LINK="https://ftp.debian.org/debian/pool/main/l/linux-signed-i386/linux-image-6.5.0-0.deb12.4-686_6.5.10-1~bpo12+1_i386.deb"
   echo "$LINK"
   DEB="${LINK##*/}"
   wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
   chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
   echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
   chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
   fi
   
   if [ "$DEB_VER" = "9" ];then
   chroot "${CHROOT}" apt install -y network-manager network-manager-gnome
		if [[ "$ARCH" =~ (i386|amd64) ]]; then
		chroot "${CHROOT}" apt remove -y chromium 2>/dev/null
		for files in \
		chromium-browser_90.0.4430.72-0ubuntu0.16.04.1_"$ARCH".deb \
		chromium-codecs-ffmpeg_90.0.4430.72-0ubuntu0.16.04.1_"$ARCH".deb \
		chromium-codecs-ffmpeg-extra_90.0.4430.72-0ubuntu0.16.04.1_"$ARCH".deb ;do
		LINK="https://archive.ubuntu.com/ubuntu/pool/universe/c/chromium-browser/$files"
		DEB="${LINK##*/}"
		wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
		chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
		echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
		chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
		done
		chroot "${CHROOT}" ln -sf /usr/bin/chromium-browser /usr/bin/x-www-browser
		fi
   fi
 
   if [ -z "$clipboard" ];then
   LINK="http://ftp.us.debian.org/debian/pool/main/p/parcellite/parcellite_1.2.1-9_$ARCH.deb"
   echo "$LINK"
   DEB="${LINK##*/}"
   wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
   chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
   echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
   chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
   fi
   
   LINK="http://ftp.us.debian.org/debian/pool/main/libg/libglade2/libglade2-0_2.6.4-2.3_$ARCH.deb"
   echo "$LINK"
   DEB="${LINK##*/}"
   wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
   chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
   echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
   chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
   
   if [ -z "$vte9" ];then
   LINK="http://ftp.us.debian.org/debian/pool/main/v/vte/libvte9_0.28.2-6+b1_$ARCH.deb"
   echo "$LINK"
   DEB="${LINK##*/}"
   wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
   chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
   echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
   chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
   fi

   if [ -z "$xml2" ];then
   LINK="http://ftp.us.debian.org/debian/pool/main/libx/libxml2/libxml2_2.12.7+dfsg+really2.9.14-2.1+deb13u2_$ARCH.deb"
   echo "$LINK"
   DEB="${LINK##*/}"
   wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
   chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
   echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
   chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
   fi

  LINK="https://mxrepo.com/mx/repo/pool/main/g/gtkdialog/gtkdialog_0.8.3-3mx17+1_$ARCH.deb"
  echo "$LINK"
  DEB="${LINK##*/}"  
  wget -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
  if [[ -f "$CHROOT"/home/live/"$DEB" ]];then
  chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
  echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
  chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
  fi
  
  #emoticons for web apps (discord, pidgin, etc..)
  LINK="http://ftp.us.debian.org/debian/pool/main/f/fonts-noto-color-emoji/fonts-noto-color-emoji_2.051-1_all.deb"
  echo "$LINK"
  DEB="${LINK##*/}"
  wget  -O "$CHROOT"/home/live/"$DEB" -q --no-check-certificate --user-agent="${uagent}" "$LINK"
  if [[ -f "$CHROOT"/home/live/"$DEB" ]];then
  chroot "${CHROOT}" dpkg -I /home/live/"${DEB}" >> "$ISO_ROOT"/hidden-packages/status
  echo -e "URL: $LINK\n\n"  >> "$ISO_ROOT"/hidden-packages/status
  chroot "${CHROOT}" dpkg-deb -X /home/live/"${DEB}" / > "$ISO_ROOT"/hidden-packages/${DEB/.deb/.list}
  fi 
  #remove downloaded debs
  rm -f "${CHROOT}"/home/live/*.deb

chroot "${CHROOT}" apt install adwaita-icon-theme-legacy 2>/dev/null

# comment next line, if u want keep doc and man page files ( ~45 Mb )
rm -rf "$CHROOT"/usr/share/doc/*
rm -rf "$CHROOT"/usr/share/man/*
rm -rf "$CHROOT"/usr/share/lintian/overrides/*

# Clean up temporary .deb files
rm -f "$CHROOT"/var/cache/apt/archives/*.deb
rm -f "$CHROOT"/var/cache/apt/archives/partial/*.deb
# remove databases
rm -rf "$CHROOT"/var/lib/apt/lists/*merged*

rm -f "$CHROOT"/etc/rc[06].d/*hwclock* 2>/dev/null
rm -rf "$CHROOT"/debootstrap

#split rootfs pkgs
echo -e "\n\n ### the following  do was by the user ###\n\n" >> "$CHROOT"/var/log/dpkg.log 

# fixing start-stop-daemon
chroot "$CHROOT" mv -f /sbin/start-stop-daemon.REAL /sbin/start-stop-daemon

# made permissions for user
echo "live ALL=(ALL) NOPASSWD: ALL" > "$CHROOT"/etc/sudoers.d/live

CURRENT_HOSTNAME=$(hostname)
HN="devuanpup"
echo "$HN" > "$CHROOT"/etc/hostname
echo "127.0.1.1	$HN" >> "$CHROOT"/etc/hosts
chroot "$CHROOT" hostname "$HN"

[ "$fshot" == "scrot" ]&& ssaver='scrot ~/Desktop/screenshot_%Y-%m-%d_%H-%M-%S.jpg<' || ssaver='flameshot full -p ~/Desktop<'
sed -i "s/Clearlooks/Greybird/ ; s/r>4/r>2/ ; s:scrot<:$ssaver:" "$CHROOT"/etc/xdg/openbox/rc.xml
sed -i '/transparent=/s/=0/=1/ ; /tintcolor=/s/#.*/#000000/ ; /alpha=/s/=.*/=91/ ; /background=/s/=1/=0/ ; /ClockFmt=/s/=.*/=%R %A %x/ ; s/ont=0/ont=1/ ;
/tray$/s/^/ type = thermal\n  Config \{\n    NormalColor=#00ff00\n    Warning1Color=#fff000\n    Warning2Color=#ff0000\n    AutomaticLevels=1\n    Warning1Temp=75\n    Warning2Temp=85\n    AutomaticSensor=1\n  \}\n\}\n\nPlugin \{\n/ ;
 /my-comp/s:=.*:=/usr/share/doc/puplogos/devuanlogo.jpg:' "$CHROOT"/etc/xdg/lxpanel/default/panels/panel
grep -q "type = volume" "$CHROOT"/etc/xdg/lxpanel/default/panels/panel || sed -i '/tray$/s/$/\n\}\nPlugin \{\n  type = volume/' "$CHROOT"/etc/xdg/lxpanel/default/panels/panel
echo -e "[Command]\nLogout=obsession-logout\n" >  "$CHROOT"/etc/xdg/lxpanel/default/config

wget --no-check-certificate --user-agent="${uagent}" -q -O "${CHROOT}"/usr/share/backgrounds/default.jpg "https://live.staticflickr.com/7419/8718023436_d05c771bd0_b.jpg"

cat << EOF >> "$CHROOT"/etc/lightdm/lightdm-gtk-greeter.conf
background=/usr/share/backgrounds/default.jpg
EOF

sed -i '/#*au.*er=/s/.*/autologin-user=live/ ; /#*au.*ut=/s/#//g ; /#gr.*rs=\|#gr.*l-l\|#al.*st/{s/#// ; s/true/false/}' "$CHROOT"/etc/lightdm/lightdm.conf
#add user rw/exec mount access
sed -i '/l_d.*=$/s:# *:: ; /l_d.*=$/s:=:= \*: ; /755$/s/55/77/ ; /^def.*ns \|^def.*_[vmen]/s/ noexec,//g' "$CHROOT"/etc/udevil/udevil.conf

sed -i '/256/s:):|lxterminal):' "$CHROOT"/etc/skel/.bashrc
sed -i '/pkexec/s/=.*/=sudo synaptic/' "$CHROOT"/usr/share/applications/synaptic.desktop 2>/dev/null
sed -i '/^Exec/s/=/=sudo /' "$CHROOT"/usr/share/applications/wpa_gui.desktop 2>/dev/null
sed -i '/^Exec/s/=/=dbus-run-session /' "$CHROOT"/usr/share/applications/chromium*.desktop 2>/dev/null

#set lxpanel launchers
cd "$CHROOT"/usr/share/applications
www="$(ls {chromium*,iron*,firefox*,opera*,vivaldi*} 2>/dev/null | head -n1)"
[ -n "$www" ]&& ln -sf "$www" lxde-x-www-browser.desktop 
terminal="$(ls {lxterminal*,xfce4-terminal*,gnome-terminal*,konsole*,urxvt*,rxvt*,xterm*} 2>/dev/null | head -n1)"
[ -n "$terminal" ]&& ln -sf "$terminal" lxde-x-terminal-emulator.desktop
cd "$DIR"
echo 'Path askpass /usr/sbin/sudo-askpass' >> "$CHROOT"/etc/sudo.conf

J=""
J="$CHROOT/home/live/startup.sh"
cat << 'EOJ' > "$J" && chmod +x "$J"
#!/bin/bash
for i in "$HOME"/Startup/*;do
 [ -x "$i" ]&& . "$i"
done
EOJ
cp "$CHROOT"/home/live/startup.sh "$CHROOT"/root/startup.sh

cat >> "$CHROOT"/etc/xdg/openbox/autostart <<'EOF'
EX="$(grep ^E "$HOME"/.config/autostart/lxrandr-autostart.desktop 2>/dev/null | cut -f2 -d"'")"
${EX}

# enable touchpad tap click
synclient TapButton1=1 &

spacefm --desktop &
lxpanel &
connman-gtk &
dunst &
[ -e /var/lib/live/config/ntpdate ]&& set-network-time &
"$HOME"/startup.sh &
grep -qi touchpad /sys/class/input/*/name && numlockx off &
1st_run_script
EOF

# add gtk2/3 syswide theme
GTK_CONFIG='gtk-icon-theme-name="adwaita"
gtk-theme-name="Greybird"
gtk-font-name="Nimbus Mono L Bold 10"
gtk-cursor-theme-size=0
gtk-toolbar-style=GTK_TOOLBAR_ICONS
gtk-toolbar-icon-size=GTK_ICON_SIZE_LARGE_TOOLBAR
gtk-button-images=1
gtk-menu-images=1
gtk-enable-event-sounds=0
gtk-enable-input-feedback-sounds=1
gtk-xft-antialias=1
gtk-xft-hinting=1
gtk-xft-hintstyle="hintfull"
gtk-xft-rgba="rgb"
gtk-cursor-theme-name="Adwaita"'

echo '# DO NOT EDIT! This file will be overwritten by LXAppearance.
# Any customization should be done in ~/.gtkrc-2.0.mine instead.

#include "~/.gtkrc-2.0.mine"
'$GTK_CONFIG'
' > "$CHROOT"/etc/gtk-2.0/gtkrc

echo "[Settings]
$GTK_CONFIG
" | sed 's/"//g' > "$CHROOT"/etc/gtk-3.0/settings.ini

chroot "$CHROOT" xdg-mime default filemnt.desktop "$(echo "application/x-"{ext{2..4},cd,squashfs}"-image")"
chroot "$CHROOT" xdg-mime default mpv.desktop m3u8 xspf pls

sed -i '/gpic/s/firefox-esr\.desktop\;// ; /directory/s/=.*/=spacefm.desktop;/' $CHROOT/usr/share/applications/mimeinfo.cache

chroot "$CHROOT" chown -R live:live /home/live

chroot "$CHROOT"  dpkg -l | tail -n +6 | awk '{printf "%-4s %-35s %-25s %-6s %s\n", $1, $2, $3, $4, substr($0, index($0,$5))}' > "$ISO_ROOT"/Packages

#generate desktop icon storage
#/etc/dpkg/dpkg.cfg.d/desktopicons call /usr/bin/dpkg-desktop-icons
DICONS="$CHROOT/var/log/desktop-icon-storage"
for desktop_file in "$CHROOT"/usr/share/applications/*.desktop ; do
  [ -f "$desktop_file" ] || continue
  basename "$desktop_file" >> "$DICONS"
done
sort -u "$DICONS" -o "$DICONS"
rm -f "$CHROOT"/root/Desktop/* "$CHROOT"/home/live/Desktop/*
cp  "$CHROOT"/usr/share/applications/{firefox-esr,spacefm,chromium*}.desktop "$CHROOT"/home/live/Desktop 2>/dev/null
cp  "$CHROOT"/usr/share/applications/{firefox-esr,spacefm,chromium*}.desktop "$CHROOT"/root/Desktop 2>/dev/null

cp -rf ./rootfs-skeleton/* "$CHROOT"

#made rcS.d setup for quicksetup
chroot "$CHROOT"  update-rc.d quicksetup.sh start 7 S .

echo -e "\n	--------------------------------------------------\n	Default kernel boot parameters (grub4dos):\n
[ menu.lst ]
kernel /$DISTRO_FILE_PREFIX/vmlinuz quiet psubdir=$DISTRO_FILE_PREFIX
initrd /$DISTRO_FILE_PREFIX/initrd-modules.gz /$DISTRO_FILE_PREFIX/initrd.gz
" > "$ISO_ROOT"/boot_parameters.txt
# END of chroot
#-----------------------------------------------------

#define /usr if merged sys
if ${MERGED} ;then
U=/usr
label=usrmerged_
else
U=
label=
fi

mkdir -p "${DIR}/zdrv"/boot

# make new initrd
chroot "$CHROOT" /initrd/mkinitrd
cp -f "$CHROOT"/initrd*.gz "${DIR}/zdrv"/boot
mv -f "$CHROOT"/initrd*.gz "$ISO_LIVE"
rm -rf "$CHROOT"/initrd* "$CHROOT"/vmlinuz*

cp "$CHROOT"/boot/vmlinuz* "${ISO_LIVE}"/vmlinuz
mv -f "$CHROOT"/boot/[cSv]* "${DIR}/zdrv"/boot
rm -f "$CHROOT"/boot/*

echo -e "\nCreate ${DISTRO_ZDRVSFS}...\n"
mkdir -p "${DIR}/zdrv$U/lib/modules"
mv -f "$(realpath "$CHROOT"/lib/modules)" "${DIR}/zdrv"$U/lib
mksquashfs "${DIR}/zdrv" "${ISO_LIVE}"/"${DISTRO_ZDRVSFS}" 2>&1 | grep "]"

echo -e "\nCreate ${DISTRO_FDRVSFS}...\n"
mkdir -p "${DIR}/fdrv$U/lib/firmware"
mv -f "$(realpath "$CHROOT"/lib/firmware)" "${DIR}/fdrv"$U/lib
mksquashfs "${DIR}/fdrv" "${ISO_LIVE}"/"${DISTRO_FDRVSFS}" 2>&1 | grep "]"

echo -e "\nCreate ${DISTRO_PUPPYSFS}...\n"
rm -rf "${ISO_LIVE}"/"${DISTRO_PUPPYSFS}".sfs 2>/dev/null && sync
mksquashfs "${CHROOT}" "${ISO_LIVE}"/"${DISTRO_PUPPYSFS}" 2>&1 | grep "]"

hostname "$CURRENT_HOSTNAME"

#sed -i "/^$\|^I:\|^\[/d" "$LOG"
echo -e "\n\n ### System build has finished.\n\n Output directory:\n  $ISO_ROOT \n\n  Contents: \n"
echo
du -ah "$ISO_ROOT" | sed 's@'"$DIR"'@@ ; s@ISO/*@@'
