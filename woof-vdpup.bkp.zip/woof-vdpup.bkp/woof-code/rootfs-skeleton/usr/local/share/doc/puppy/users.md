# Users

## Creating a User

To create a new unprivileged user named `lassie`, which can be used with the `puser=` [boot code](boot-codes.md):

	adduser lassie
	adduser lassie audio
	adduser lassie video
	adduser lassie render
	adduser lassie input
	adduser lassie lpadmin
