#!/bin/sh
### BEGIN INIT INFO
# Provides:          quicksetup
# Required-Start:
# Required-Stop:
# Default-Start:     S
# Default-Stop:
# Short-Description: wrap kernel line (live) options for set
### END INIT INFO

PATH=/usr/sbin:/usr/bin:/sbin:/bin

case "$1" in
  start)
	/usr/sbin/quicksetup start
    ;;
  *)
    echo "usage: $0 start"
    exit 1
    ;;
esac

exit 0
